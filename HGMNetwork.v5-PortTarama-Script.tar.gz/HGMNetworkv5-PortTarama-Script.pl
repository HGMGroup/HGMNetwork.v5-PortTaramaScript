#!/bin/perl

############################################
##\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\##
##========================================##
## TCP // UDP Tabanli Port Tarama Scripti ##
##========================================##
##    HGMNetworkv5 V5.22 Guncellemesi.    ##
##========================================##
##////////////////////////////////////////##
############################################
use IO::Socket;
######################################
if ($#ARGV != 3) {
  print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] - \e[38;5;196mHATA: \e[38;5;226mTarama Baslatilamadi, \e[38;5;196mLutfen Tekrar Deneyin...\e[0m";
  exit(1);
}
######################################
binmode STDOUT, ":encoding(UTF-8)";
######################################

my ($HGMNetwork_PortTarama_ProtokolTuru,$HGMNetwork_PortTarama_HedefIP,$HGMNetwork_PortTarama_BaslangicPort,$HGMNetwork_PortTarama_BitisPort) = @ARGV;

if ( $HGMNetwork_PortTarama_ProtokolTuru eq "HGMNetwork_PortTarama_Porotokol_TCPTarama") {

if ( $HGMNetwork_PortTarama_BaslangicPort > $HGMNetwork_PortTarama_BitisPort ) {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] - \e[38;5;196mHATA: \e[38;5;226mBitis Portu Baslangicdan Buyuk \e[38;5;196mOLAMAZ..!\e[0m";
}

my $HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_BaslangicPort;

while ( $HGMNetwork_PortTarama_PortSonuc <= $HGMNetwork_PortTarama_BitisPort ) {

$HGMNetwork_PortTarama_PaketGonder = IO::Socket::INET->new(PeerAddr=>$HGMNetwork_PortTarama_HedefIP,PeerPort=>$HGMNetwork_PortTarama_PortSonuc,proto=>'tcp',Timeout=>5);

if ( $HGMNetwork_PortTarama_PaketGonder ) {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] \e[38;5;51m|| [\e[38;5;46mTCP\e[38;5;51m] \e[38;5;226mPort: \e[38;5;46m-> \e[38;5;51m[\e[38;5;46m$HGMNetwork_PortTarama_PortSonuc\e[38;5;51m]\e[38;5;46m Acik.\e[0m\n";
close $HGMNetwork_PortTarama_PaketGonder;
$HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_PortSonuc + 1;
}

else {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] \e[38;5;51m|| [\e[38;5;196mTCP\e[38;5;51m] \e[38;5;226mPort: \e[38;5;46m-> \e[38;5;51m[\e[38;5;196m$HGMNetwork_PortTarama_PortSonuc\e[38;5;51m]\e[38;5;196m Kapali.\e[0m\n";
close $HGMNetwork_PortTarama_PaketGonder;
$HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_PortSonuc + 1;}
}
}

if ( $HGMNetwork_PortTarama_ProtokolTuru eq "HGMNetwork_PortTarama_Porotokol_UDPTarama") {

if ( $HGMNetwork_PortTarama_BaslangicPort > $HGMNetwork_PortTarama_BitisPort ) {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] - \e[38;5;196mHATA: \e[38;5;226mBitis Portu Baslangicdan Buyuk \e[38;5;196mOLAMAZ..!\e[0m";
}

my $HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_BaslangicPort;

while ( $HGMNetwork_PortTarama_PortSonuc <= $HGMNetwork_PortTarama_BitisPort ) {

$HGMNetwork_PortTarama_PaketGonder = IO::Socket::INET->new(PeerAddr=>$HGMNetwork_PortTarama_HedefIP,PeerPort=>$HGMNetwork_PortTarama_PortSonuc,proto=>'udp',Timeout=>5);

if ( $HGMNetwork_PortTarama_PaketGonder ) {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] \e[38;5;51m|| [\e[38;5;46mUDP\e[38;5;51m] \e[38;5;226mPort: \e[38;5;46m-> \e[38;5;51m[\e[38;5;46m$HGMNetwork_PortTarama_PortSonuc\e[38;5;51m]\e[38;5;46m Acik.\e[0m\n";
close $HGMNetwork_PortTarama_PaketGonder;
$HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_PortSonuc + 1;
}

else {
print "\e[38;5;51m[\e[38;5;196mHGMNetwork\e[38;5;51m] \e[38;5;51m|| [\e[38;5;196mUDP\e[38;5;51m] \e[38;5;226mPort: \e[38;5;46m-> \e[38;5;51m[\e[38;5;196m$HGMNetwork_PortTarama_PortSonuc\e[38;5;51m]\e[38;5;196m Kapali.\e[0m\n";
close $HGMNetwork_PortTarama_PaketGonder;
$HGMNetwork_PortTarama_PortSonuc = $HGMNetwork_PortTarama_PortSonuc + 1;}
}
}